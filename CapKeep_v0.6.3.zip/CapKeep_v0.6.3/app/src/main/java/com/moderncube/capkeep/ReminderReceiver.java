package com.moderncube.capkeep;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL_ID = "capkeep_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"캡처 알림",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(context,MainActivity.class);
        PendingIntent pending=PendingIntent.getActivity(context,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String title=intent.getStringExtra("title"); if(title==null||title.isEmpty()) title="저장한 캡처를 확인할 시간이에요";
        NotificationCompat.Builder n=new NotificationCompat.Builder(context,CHANNEL_ID).setSmallIcon(com.moderncube.capkeep.R.drawable.app_icon).setContentTitle("캡킵 알림").setContentText(title).setAutoCancel(true).setContentIntent(pending).setPriority(NotificationCompat.PRIORITY_HIGH);
        manager.notify(intent.getIntExtra("id",1),n.build());
    }
}
