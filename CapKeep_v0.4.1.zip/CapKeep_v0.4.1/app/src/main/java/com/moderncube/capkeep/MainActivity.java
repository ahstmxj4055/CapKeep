package com.moderncube.capkeep;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PHOTO_PERMISSION=41, NOTIFICATION_PERMISSION=42, DELETE_REQUEST=43;
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private WebView webView;
    private boolean pageReady=false, refreshRunning=false;
    private TextRecognizer recognizer;
    private SharedPreferences analysisCache;
    private String pendingReminderTitle;
    private long pendingReminderTime;
    private int pendingReminderId;

    private final ContentObserver mediaObserver=new ContentObserver(mainHandler){
        @Override public void onChange(boolean selfChange,Uri uri){mainHandler.removeCallbacks(autoRefresh);mainHandler.postDelayed(autoRefresh,900);}
    };
    private final Runnable autoRefresh=()->{if(hasPhotoPermission())refreshScreenshotsAsync(false);};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        analysisCache=getSharedPreferences("capkeep_analysis",MODE_PRIVATE);
        recognizer=TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        webView=new WebView(this);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AppBridge(),"CapKeepAndroid");
        webView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){pageReady=true;if(hasPhotoPermission())refreshScreenshotsAsync(false);}});
        webView.loadUrl("file:///android_asset/index.html");setContentView(webView);
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,true,mediaObserver);
    }

    private String photoPermission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE;}
    private boolean hasPhotoPermission(){return Build.VERSION.SDK_INT<23||checkSelfPermission(photoPermission())==PackageManager.PERMISSION_GRANTED;}
    private void askPhotoPermission(){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{photoPermission()},PHOTO_PERMISSION);}

    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==PHOTO_PERMISSION){boolean ok=hasPhotoPermission();webView.evaluateJavascript("window.onPhotoPermission("+ok+")",null);if(ok)refreshScreenshotsAsync(true);}
        if(code==NOTIFICATION_PERMISSION&&Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED){scheduleReminderNow(pendingReminderTitle,pendingReminderTime,pendingReminderId);}
    }

    @Override protected void onResume(){super.onResume();if(pageReady&&hasPhotoPermission())mainHandler.postDelayed(()->refreshScreenshotsAsync(false),350);}

    private class AppBridge{
        @JavascriptInterface public boolean hasPermission(){return hasPhotoPermission();}
        @JavascriptInterface public void requestPermission(){runOnUiThread(()->askPhotoPermission());}
        @JavascriptInterface public void refreshScreenshots(){refreshScreenshotsAsync(true);}
        @JavascriptInterface public void deleteScreenshots(String ids){runOnUiThread(()->requestDelete(ids));}
        @JavascriptInterface public void scheduleReminder(String title,long time,int id){runOnUiThread(()->prepareReminder(title,time,id));}
        @JavascriptInterface public void cancelReminder(int id){runOnUiThread(()->cancelReminderNow(id));}
    }

    private synchronized void refreshScreenshotsAsync(boolean showMessage){
        if(refreshRunning||!hasPhotoPermission())return;refreshRunning=true;
        new Thread(()->{JSONArray items=queryScreenshots();String result=items.toString();runOnUiThread(()->{refreshRunning=false;if(!pageReady||webView==null)return;webView.evaluateJavascript("window.receiveScreenshots("+JSONObject.quote(result)+","+showMessage+")",null);analyzeMissing(items);});},"CapKeepGallery").start();
    }

    private JSONArray queryScreenshots(){
        JSONArray out=new JSONArray();boolean modern=Build.VERSION.SDK_INT>=29;
        String[] cols=modern?new String[]{MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.DATE_ADDED,MediaStore.Images.Media.RELATIVE_PATH}:new String[]{MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.DATE_ADDED,MediaStore.Images.Media.DATA};
        String location=modern?MediaStore.Images.Media.RELATIVE_PATH:MediaStore.Images.Media.DATA;
        String selection="("+location+" LIKE ? OR "+MediaStore.Images.Media.DISPLAY_NAME+" LIKE ? OR "+MediaStore.Images.Media.DISPLAY_NAME+" LIKE ? OR "+MediaStore.Images.Media.DISPLAY_NAME+" LIKE ?)";
        String[] args={"%Screenshots%","%Screenshot%","%스크린샷%","%Capture%"};
        try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cols,selection,args,MediaStore.Images.Media.DATE_ADDED+" DESC")){
            if(c==null)return out;int idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID),nameCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME),dateCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
            while(c.moveToNext()&&out.length()<120){long id=c.getLong(idCol);String name=c.getString(nameCol);if(name==null)name="스크린샷";Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));JSONObject item=new JSONObject();item.put("id",id);item.put("name",name);item.put("date",c.getLong(dateCol));item.put("thumb",thumbnail(uri,id));item.put("category",analysisCache.getString("cat_"+id,"분석 중"));item.put("text",analysisCache.getString("text_"+id,""));out.put(item);}
        }catch(Exception e){try{JSONObject error=new JSONObject();error.put("error",e.getClass().getSimpleName()+": "+e.getMessage());out.put(error);}catch(Exception ignored){}}
        return out;
    }

    private String thumbnail(Uri uri,long id){Bitmap src=null;try{if(Build.VERSION.SDK_INT>=29)src=getContentResolver().loadThumbnail(uri,new Size(360,360),null);else src=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),id,MediaStore.Images.Thumbnails.MINI_KIND,null);if(src==null)return"";ByteArrayOutputStream bytes=new ByteArrayOutputStream();src.compress(Bitmap.CompressFormat.JPEG,72,bytes);src.recycle();return"data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP);}catch(Exception e){if(src!=null)src.recycle();return"";}}

    private void analyzeMissing(JSONArray items){
        analyzeNext(items,0,0);
    }
    private void analyzeNext(JSONArray items,int index,int processed){
        if(index>=items.length()||processed>=40)return;
        try{JSONObject item=items.getJSONObject(index);if(item.has("error")){analyzeNext(items,index+1,processed);return;}long id=item.getLong("id");if(analysisCache.contains("cat_"+id)){analyzeNext(items,index+1,processed);return;}Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));InputImage image=InputImage.fromFilePath(this,uri);recognizer.process(image).addOnSuccessListener(result->{String text=result.getText();String category=classify(text);analysisCache.edit().putString("cat_"+id,category).putString("text_"+id,text).apply();webView.evaluateJavascript("window.updateAnalysis("+id+","+JSONObject.quote(category)+","+JSONObject.quote(text)+")",null);analyzeNext(items,index+1,processed+1);}).addOnFailureListener(e->{analysisCache.edit().putString("cat_"+id,"메모").apply();webView.evaluateJavascript("window.updateAnalysis("+id+",'메모','')",null);analyzeNext(items,index+1,processed+1);});}catch(Exception e){analyzeNext(items,index+1,processed);}
    }

    private String classify(String value){String t=value.toLowerCase(Locale.KOREA);if(hasAny(t,"쿠폰","유효기간","바코드","할인코드"))return"쿠폰";if(hasAny(t,"예약","체크인","탑승","티켓","숙박"))return"예약";if(hasAny(t,"메뉴","맛집","카페","식당","배달","음식"))return"맛집";if(hasAny(t,"계좌","입금","은행","송금"))return"계좌";if(hasAny(t,"원","가격","결제","주문","상품","쿠팡","장바구니","배송"))return"쇼핑";return"메모";}
    private boolean hasAny(String text,String...words){for(String w:words)if(text.contains(w))return true;return false;}

    private void requestDelete(String raw){
        try{JSONArray ids=new JSONArray(raw);ArrayList<Uri> uris=new ArrayList<>();for(int i=0;i<ids.length();i++)uris.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(ids.getLong(i))));if(uris.isEmpty())return;
            if(Build.VERSION.SDK_INT>=30){PendingIntent request=MediaStore.createDeleteRequest(getContentResolver(),uris);startIntentSenderForResult(request.getIntentSender(),DELETE_REQUEST,null,0,0,0);}else{for(Uri uri:uris)getContentResolver().delete(uri,null,null);onDeleteFinished(true);}
        }catch(Exception e){onDeleteFinished(false);}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==DELETE_REQUEST)onDeleteFinished(resultCode==RESULT_OK);}
    private void onDeleteFinished(boolean ok){webView.evaluateJavascript("window.onDeleteResult("+ok+")",null);if(ok)refreshScreenshotsAsync(false);}

    private void prepareReminder(String title,long time,int id){
        pendingReminderTitle=title;pendingReminderTime=time;pendingReminderId=id;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);return;}
        scheduleReminderNow(title,time,id);
    }
    private void scheduleReminderNow(String title,long time,int id){
        try{Intent intent=new Intent(this,ReminderReceiver.class).putExtra("title",title).putExtra("id",id);PendingIntent pending=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending);webView.evaluateJavascript("window.onReminderScheduled(true)",null);}catch(Exception e){webView.evaluateJavascript("window.onReminderScheduled(false)",null);}
    }
    private void cancelReminderNow(int id){Intent intent=new Intent(this,ReminderReceiver.class);PendingIntent pending=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pending!=null){AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);alarm.cancel(pending);pending.cancel();}}

    @Override public void onBackPressed(){webView.evaluateJavascript("document.querySelector('.screen.on').id",value->{if("\"home\"".equals(value))finish();else webView.evaluateJavascript("window.appBack()",null);});}
    @Override protected void onDestroy(){mainHandler.removeCallbacksAndMessages(null);try{getContentResolver().unregisterContentObserver(mediaObserver);}catch(Exception ignored){}if(recognizer!=null)recognizer.close();if(webView!=null)webView.destroy();super.onDestroy();}
}
