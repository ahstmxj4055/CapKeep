package com.moderncube.capkeep;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PHOTO_PERMISSION = 41;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WebView webView;
    private boolean pageReady = false;
    private boolean refreshRunning = false;

    private final ContentObserver mediaObserver = new ContentObserver(mainHandler) {
        @Override public void onChange(boolean selfChange, Uri uri) {
            mainHandler.removeCallbacks(autoRefresh);
            mainHandler.postDelayed(autoRefresh, 800);
        }
    };
    private final Runnable autoRefresh = () -> { if (hasFullPhotoPermission()) refreshScreenshotsAsync(false); };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new GalleryBridge(), "CapKeepAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (hasFullPhotoPermission()) refreshScreenshotsAsync(false);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, mediaObserver);
    }

    private String fullPermission() { return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE; }
    private boolean hasFullPhotoPermission() { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(fullPermission()) == PackageManager.PERMISSION_GRANTED; }
    private void askPhotoPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, PHOTO_PERMISSION);
        else if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PHOTO_PERMISSION);
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == PHOTO_PERMISSION) {
            boolean granted = hasFullPhotoPermission();
            webView.evaluateJavascript("window.onPhotoPermission(" + granted + ")", null);
            if (granted) refreshScreenshotsAsync(true);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (pageReady && hasFullPhotoPermission()) mainHandler.postDelayed(() -> refreshScreenshotsAsync(false), 350);
    }

    private class GalleryBridge {
        @JavascriptInterface public boolean hasPermission() { return hasFullPhotoPermission(); }
        @JavascriptInterface public void requestPermission() { runOnUiThread(() -> askPhotoPermission()); }
        @JavascriptInterface public void refreshScreenshots() { refreshScreenshotsAsync(true); }
    }

    private synchronized void refreshScreenshotsAsync(boolean showMessage) {
        if (refreshRunning || !hasFullPhotoPermission()) return;
        refreshRunning = true;
        new Thread(() -> {
            String result = queryScreenshots();
            runOnUiThread(() -> {
                refreshRunning = false;
                if (!pageReady || webView == null) return;
                String js = "window.receiveScreenshots(" + JSONObject.quote(result) + "," + showMessage + ")";
                webView.evaluateJavascript(js, null);
            });
        }, "CapKeepGallery").start();
    }

    private String queryScreenshots() {
        JSONArray out = new JSONArray();
        boolean modern = Build.VERSION.SDK_INT >= 29;
        String[] cols = modern
            ? new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.RELATIVE_PATH}
            : new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATA};
        String locationColumn = modern ? MediaStore.Images.Media.RELATIVE_PATH : MediaStore.Images.Media.DATA;
        String selection = "(" + locationColumn + " LIKE ? OR " + MediaStore.Images.Media.DISPLAY_NAME + " LIKE ? OR " + MediaStore.Images.Media.DISPLAY_NAME + " LIKE ? OR " + MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?)";
        String[] args = new String[]{"%Screenshots%", "%Screenshot%", "%스크린샷%", "%Capture%"};
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cols, selection, args, MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            if (c == null) return out.toString();
            int idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID), nameCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME), dateCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
            while (c.moveToNext() && out.length() < 120) {
                long id=c.getLong(idCol); String name=c.getString(nameCol); if(name==null) name="스크린샷";
                Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                JSONObject item=new JSONObject(); item.put("id",id); item.put("name",name); item.put("date",c.getLong(dateCol)); item.put("thumb",thumbnail(uri,id)); out.put(item);
            }
        } catch (Exception e) {
            try { JSONObject error=new JSONObject(); error.put("error",e.getClass().getSimpleName()); out.put(error); } catch(Exception ignored) {}
        }
        return out.toString();
    }

    private String thumbnail(Uri uri, long id) {
        Bitmap src = null;
        try {
            if (Build.VERSION.SDK_INT >= 29) src=getContentResolver().loadThumbnail(uri,new Size(360,360),null);
            else src=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),id,MediaStore.Images.Thumbnails.MINI_KIND,null);
            if(src==null) return "";
            ByteArrayOutputStream bytes=new ByteArrayOutputStream(); src.compress(Bitmap.CompressFormat.JPEG,72,bytes); src.recycle();
            return "data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP);
        } catch(Exception e) { if(src!=null) src.recycle(); return ""; }
    }

    @Override public void onBackPressed() { webView.evaluateJavascript("document.querySelector('.screen.on').id", value -> { if("\"home\"".equals(value)) finish(); else webView.evaluateJavascript("window.appBack()",null); }); }
    @Override protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        try { getContentResolver().unregisterContentObserver(mediaObserver); } catch(Exception ignored) {}
        if(webView!=null) webView.destroy();
        super.onDestroy();
    }
}
