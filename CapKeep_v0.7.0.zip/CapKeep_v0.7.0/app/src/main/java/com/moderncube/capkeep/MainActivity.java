package com.moderncube.capkeep;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Size;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.android.gms.tasks.Tasks;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PHOTO_PERMISSION=41, NOTIFICATION_PERMISSION=42, DELETE_REQUEST=43, WRITE_REQUEST=44;
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private WebView webView;
    private boolean pageReady=false, refreshRunning=false, analysisRunning=false;
    private TextRecognizer latinRecognizer,koreanRecognizer,japaneseRecognizer,chineseRecognizer;
    private SharedPreferences analysisCache,appSettings;
    private String pendingReminderTitle;
    private long pendingReminderTime;
    private int pendingReminderId;
    private long pendingRenameId;
    private String pendingRenameName;
    private final ArrayList<Uri> pendingDeleteUris=new ArrayList<>();

    private final ContentObserver mediaObserver=new ContentObserver(mainHandler){
        @Override public void onChange(boolean selfChange,Uri uri){mainHandler.removeCallbacks(autoRefresh);mainHandler.postDelayed(autoRefresh,900);}
    };
    private final Runnable autoRefresh=()->{if(hasPhotoPermission()&&appSettings.getBoolean("autoImport",true))refreshScreenshotsAsync(false);};

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        analysisCache=getSharedPreferences("capkeep_analysis",MODE_PRIVATE);
        appSettings=getSharedPreferences("capkeep_settings",MODE_PRIVATE);
        latinRecognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        koreanRecognizer=TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
        japaneseRecognizer=TextRecognition.getClient(new JapaneseTextRecognizerOptions.Builder().build());
        chineseRecognizer=TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        webView=new WebView(this);
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);
        webView.addJavascriptInterface(new AppBridge(),"CapKeepAndroid");
        webView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){pageReady=true;if(hasPhotoPermission()&&appSettings.getBoolean("autoImport",true))refreshScreenshotsAsync(false);}});
        webView.loadUrl("file:///android_asset/index.html");setContentView(webView);
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,true,mediaObserver);
    }

    private String photoPermission(){return Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_IMAGES:Manifest.permission.READ_EXTERNAL_STORAGE;}
    private boolean hasPhotoPermission(){return Build.VERSION.SDK_INT<23||checkSelfPermission(photoPermission())==PackageManager.PERMISSION_GRANTED;}
    private void askPhotoPermission(){if(Build.VERSION.SDK_INT>=23)requestPermissions(new String[]{photoPermission()},PHOTO_PERMISSION);}

    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==PHOTO_PERMISSION){boolean ok=hasPhotoPermission();webView.evaluateJavascript("window.onPhotoPermission("+ok+")",null);if(ok)refreshScreenshotsAsync(true);}
        if(code==NOTIFICATION_PERMISSION){boolean allowed=Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;if(allowed)scheduleReminderNow(pendingReminderTitle,pendingReminderTime,pendingReminderId);else webView.evaluateJavascript("window.onReminderScheduled(false)",null);}
    }

    @Override protected void onResume(){super.onResume();if(pageReady){webView.evaluateJavascript("window.refreshSettings&&window.refreshSettings()",null);if(hasPhotoPermission()&&appSettings.getBoolean("autoImport",true))mainHandler.postDelayed(()->refreshScreenshotsAsync(false),350);}}

    private class AppBridge{
        @JavascriptInterface public boolean hasPermission(){return hasPhotoPermission();}
        @JavascriptInterface public void requestPermission(){runOnUiThread(()->askPhotoPermission());}
        @JavascriptInterface public void refreshScreenshots(){refreshScreenshotsAsync(true);}
        @JavascriptInterface public void deleteScreenshots(String ids){runOnUiThread(()->requestDelete(ids));}
        @JavascriptInterface public void scheduleReminder(String title,long time,int id){runOnUiThread(()->prepareReminder(title,time,id));}
        @JavascriptInterface public void cancelReminder(int id){runOnUiThread(()->cancelReminderNow(id));}
        @JavascriptInterface public String getSettings(){return settingsJson();}
        @JavascriptInterface public void saveSettings(String raw){runOnUiThread(()->applySettings(raw));}
        @JavascriptInterface public void openAppSettings(){runOnUiThread(()->startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));}
        @JavascriptInterface public void clearAnalysis(){analysisCache.edit().clear().apply();runOnUiThread(()->{webView.evaluateJavascript("window.onAnalysisCleared()",null);refreshScreenshotsAsync(false);});}
        @JavascriptInterface public void reanalyzeScreenshot(long id,String language){reanalyzeOneAsync(id,language);}
        @JavascriptInterface public void renameScreenshot(long id,String name){runOnUiThread(()->requestRename(id,name));}
        @JavascriptInterface public void loadFullImage(long id){loadFullImageAsync(id);}
        @JavascriptInterface public void shareScreenshot(long id){runOnUiThread(()->shareScreenshotNow(id));}
        @JavascriptInterface public void copyText(String text){runOnUiThread(()->copyTextNow(text));}
        @JavascriptInterface public void openDetected(String type,String value){runOnUiThread(()->openDetectedNow(type,value));}
        @JavascriptInterface public void closeApp(){runOnUiThread(()->finish());}
    }

    private String settingsJson(){JSONObject out=new JSONObject();try{out.put("autoImport",appSettings.getBoolean("autoImport",true));out.put("ocrEnabled",appSettings.getBoolean("ocrEnabled",true));out.put("language",appSettings.getString("language","auto"));out.put("cleanupDays",appSettings.getInt("cleanupDays",30));out.put("photoPermission",hasPhotoPermission());out.put("notificationPermission",Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);}catch(Exception ignored){}return out.toString();}
    private void applySettings(String raw){try{JSONObject v=new JSONObject(raw);boolean oldOcr=appSettings.getBoolean("ocrEnabled",true);String oldLang=appSettings.getString("language","auto");boolean ocr=v.optBoolean("ocrEnabled",true);String lang=v.optString("language","auto");appSettings.edit().putBoolean("autoImport",v.optBoolean("autoImport",true)).putBoolean("ocrEnabled",ocr).putString("language",lang).putInt("cleanupDays",v.optInt("cleanupDays",30)).apply();if(oldOcr!=ocr||!oldLang.equals(lang))analysisCache.edit().clear().apply();webView.evaluateJavascript("window.onSettingsSaved()",null);if(hasPhotoPermission())refreshScreenshotsAsync(false);}catch(Exception e){webView.evaluateJavascript("window.onSettingsError()",null);}}

    private synchronized void refreshScreenshotsAsync(boolean showMessage){
        if(refreshRunning||!hasPhotoPermission())return;refreshRunning=true;
        new Thread(()->{JSONArray items=queryScreenshots();String result=items.toString();runOnUiThread(()->{refreshRunning=false;if(!pageReady||webView==null)return;webView.evaluateJavascript("window.receiveScreenshots("+JSONObject.quote(result)+","+showMessage+")",null);analyzeMissing(items);});},"CapKeepGallery").start();
    }

    private JSONArray queryScreenshots(){
        JSONArray out=new JSONArray();boolean modern=Build.VERSION.SDK_INT>=29;
        String[] cols=modern?new String[]{MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.DATE_ADDED,MediaStore.Images.Media.RELATIVE_PATH}:new String[]{MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.DATE_ADDED,MediaStore.Images.Media.DATA};
        String location=modern?MediaStore.Images.Media.RELATIVE_PATH:MediaStore.Images.Media.DATA;
        String selection="("+location+" LIKE ? OR "+MediaStore.Images.Media.DISPLAY_NAME+" LIKE ? OR "+MediaStore.Images.Media.DISPLAY_NAME+" LIKE ? OR "+MediaStore.Images.Media.DISPLAY_NAME+" LIKE ?)";
        String[] args={"%Screenshots%","%Screenshot%","%스크린샷%","%Capture%"};
        try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cols,selection,args,MediaStore.Images.Media.DATE_ADDED+" DESC")){
            if(c==null)return out;int idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID),nameCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME),dateCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
            while(c.moveToNext()&&out.length()<120){long id=c.getLong(idCol);String name=c.getString(nameCol);if(name==null)name="스크린샷";Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));JSONObject item=new JSONObject();item.put("id",id);item.put("name",name);item.put("date",c.getLong(dateCol));item.put("thumb",thumbnail(uri,id));item.put("hash",perceptualHash(uri,id));item.put("category",analysisCache.getString("cat_"+id,"분석 중"));item.put("text",analysisCache.getString("text_"+id,""));out.put(item);}
        }catch(Exception e){try{JSONObject error=new JSONObject();error.put("error",e.getClass().getSimpleName()+": "+e.getMessage());out.put(error);}catch(Exception ignored){}}
        return out;
    }

    private String thumbnail(Uri uri,long id){Bitmap src=null;try{if(Build.VERSION.SDK_INT>=29)src=getContentResolver().loadThumbnail(uri,new Size(360,360),null);else src=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),id,MediaStore.Images.Thumbnails.MINI_KIND,null);if(src==null)return"";ByteArrayOutputStream bytes=new ByteArrayOutputStream();src.compress(Bitmap.CompressFormat.JPEG,72,bytes);src.recycle();return"data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP);}catch(Exception e){if(src!=null)src.recycle();return"";}}

    private String perceptualHash(Uri uri,long id){Bitmap src=null,small=null;try{if(Build.VERSION.SDK_INT>=29)src=getContentResolver().loadThumbnail(uri,new Size(96,96),null);else src=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),id,MediaStore.Images.Thumbnails.MICRO_KIND,null);if(src==null)return"";small=Bitmap.createScaledBitmap(src,9,8,true);long hash=0;for(int y=0;y<8;y++)for(int x=0;x<8;x++){int a=small.getPixel(x,y),b=small.getPixel(x+1,y);int ga=(((a>>16)&255)*30+((a>>8)&255)*59+(a&255)*11)/100;int gb=(((b>>16)&255)*30+((b>>8)&255)*59+(b&255)*11)/100;hash=(hash<<1)|(ga>gb?1:0);}return String.format(Locale.ROOT,"%016x",hash);}catch(Exception e){return"";}finally{if(small!=null&&small!=src)small.recycle();if(src!=null)src.recycle();}}

    private void loadFullImageAsync(long id){
        new Thread(()->{String encoded="";Bitmap bitmap=null;try{Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(in,null,bounds);}int sample=1;while(Math.max(bounds.outWidth,bounds.outHeight)/sample>1800)sample*=2;BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=sample;try(InputStream in=getContentResolver().openInputStream(uri)){bitmap=BitmapFactory.decodeStream(in,null,options);}if(bitmap!=null){ByteArrayOutputStream bytes=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.JPEG,90,bytes);encoded="data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP);}}catch(Exception ignored){}finally{if(bitmap!=null)bitmap.recycle();}String result=encoded;runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript("window.showFullImageData("+id+","+JSONObject.quote(result)+")",null);});},"CapKeepFullImage").start();
    }

    private void shareScreenshotNow(long id){try{Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));Intent send=new Intent(Intent.ACTION_SEND);send.setType("image/*");send.putExtra(Intent.EXTRA_STREAM,uri);send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(send,"캡처 공유"));}catch(Exception e){webView.evaluateJavascript("toast('공유할 앱을 열지 못했어요')",null);}}
    private void copyTextNow(String text){try{ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);clipboard.setPrimaryClip(ClipData.newPlainText("캡킵 인식 글자",text==null?"":text));webView.evaluateJavascript("toast('인식된 글자를 복사했어요')",null);}catch(Exception e){webView.evaluateJavascript("toast('글자를 복사하지 못했어요')",null);}}
    private void openDetectedNow(String type,String value){try{Intent intent;if("phone".equals(type)){intent=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+value.replaceAll("[^+0-9]","")));}else if("map".equals(type)){intent=new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(value)));}else{String url=value.startsWith("http://")||value.startsWith("https://")?value:"https://"+value;intent=new Intent(Intent.ACTION_VIEW,Uri.parse(url));}startActivity(intent);}catch(Exception e){webView.evaluateJavascript("toast('연결된 앱을 열지 못했어요')",null);}}

    private void analyzeMissing(JSONArray items){
        if(analysisRunning||!appSettings.getBoolean("ocrEnabled",true))return;analysisRunning=true;
        new Thread(()->{String lang=appSettings.getString("language","auto");for(int i=0;i<items.length();i++)try{JSONObject item=items.getJSONObject(i);if(item.has("error"))continue;long id=item.getLong("id");if(analysisCache.contains("cat_"+id))continue;analyzeAndPublish(id,lang);}catch(Exception ignored){}analysisRunning=false;},"CapKeepOCR").start();
    }

    private void reanalyzeOneAsync(long id,String language){new Thread(()->{analysisCache.edit().remove("cat_"+id).remove("text_"+id).apply();analyzeAndPublish(id,language==null?"auto":language);},"CapKeepReanalyze").start();}
    private void analyzeAndPublish(long id,String lang){try{Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));InputImage image=InputImage.fromFilePath(this,uri);String text=recognize(image,lang),category=classify(text);analysisCache.edit().putString("cat_"+id,category).putString("text_"+id,text).apply();String js="window.updateAnalysis("+id+","+JSONObject.quote(category)+","+JSONObject.quote(text)+")";runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript(js,null);});}catch(Exception e){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript("toast('사진 분석에 실패했어요')",null);});}}
    private String recognize(InputImage image,String lang){if("ko".equals(lang))return runOcr(koreanRecognizer,image);if("en".equals(lang))return runOcr(latinRecognizer,image);if("ja".equals(lang))return runOcr(japaneseRecognizer,image);if("zh".equals(lang))return runOcr(chineseRecognizer,image);String korean=runOcr(koreanRecognizer,image);if(textQuality(korean)>=12)return korean;String best=korean;TextRecognizer[] others={latinRecognizer,japaneseRecognizer,chineseRecognizer};for(TextRecognizer r:others){String value=runOcr(r,image);if(textQuality(value)>textQuality(best))best=value;}return best;}
    private int textQuality(String value){if(value==null)return 0;int score=0;for(int i=0;i<value.length();i++){char c=value.charAt(i);if(Character.isLetterOrDigit(c))score+=2;else if(c=='\n'||c==' ')score++;else if(c=='�')score-=5;}return score;}
    private String runOcr(TextRecognizer target,InputImage image){try{return Tasks.await(target.process(image)).getText();}catch(Exception e){return"";}}

    private String classify(String value){String t=value.toLowerCase(Locale.ROOT);if(hasAny(t,"쿠폰","유효기간","바코드","할인코드","coupon","voucher","优惠券","クーポン"))return"쿠폰";if(hasAny(t,"예약","체크인","탑승","티켓","숙박","reservation","booking","check-in","予約","チケット","预订","机票"))return"예약";if(hasAny(t,"메뉴","맛집","카페","식당","배달","음식","menu","restaurant","cafe","food","メニュー","レストラン","菜单","餐厅"))return"맛집";if(hasAny(t,"계좌","입금","은행","송금","account","bank","transfer","銀行","口座","银行","转账"))return"계좌";if(hasAny(t,"원","가격","결제","주문","상품","쿠팡","장바구니","배송","price","order","payment","cart","shipping","価格","注文","购物车","订单"))return"쇼핑";return"메모";}
    private boolean hasAny(String text,String...words){for(String w:words)if(text.contains(w))return true;return false;}

    private void requestDelete(String raw){
        try{JSONArray ids=new JSONArray(raw);ArrayList<Uri> uris=new ArrayList<>();for(int i=0;i<ids.length();i++){Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(ids.getLong(i)));if(uriExists(uri))uris.add(uri);}if(uris.isEmpty()){notifyDeleteResult(false);return;}pendingDeleteUris.clear();pendingDeleteUris.addAll(uris);
            if(Build.VERSION.SDK_INT>=30){PendingIntent request=MediaStore.createDeleteRequest(getContentResolver(),uris);startIntentSenderForResult(request.getIntentSender(),DELETE_REQUEST,null,0,0,0);}else{for(Uri uri:uris)getContentResolver().delete(uri,null,null);onDeleteFinished(true);}
        }catch(Exception e){onDeleteFinished(false);}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==DELETE_REQUEST)onDeleteFinished(resultCode==RESULT_OK);if(requestCode==WRITE_REQUEST){if(resultCode==RESULT_OK)performRename();else webView.evaluateJavascript("window.onRenameResult(false)",null);}}
    private boolean uriExists(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{MediaStore.Images.Media._ID},null,null,null)){return c!=null&&c.moveToFirst();}catch(Exception e){return false;}}
    private void onDeleteFinished(boolean approved){if(!approved){pendingDeleteUris.clear();notifyDeleteResult(false);return;}mainHandler.postDelayed(()->verifyDeletion(0),500);}
    private void verifyDeletion(int attempt){new Thread(()->{boolean remains=false;for(Uri uri:new ArrayList<>(pendingDeleteUris))if(uriExists(uri)){remains=true;break;}boolean stillThere=remains;runOnUiThread(()->{if(stillThere&&attempt<6){mainHandler.postDelayed(()->verifyDeletion(attempt+1),450);return;}pendingDeleteUris.clear();notifyDeleteResult(!stillThere);refreshWhenIdle(0);});},"CapKeepDeleteCheck").start();}
    private void notifyDeleteResult(boolean ok){if(webView!=null)webView.evaluateJavascript("window.onDeleteResult("+ok+")",null);}
    private void refreshWhenIdle(int attempt){if(refreshRunning&&attempt<8){mainHandler.postDelayed(()->refreshWhenIdle(attempt+1),350);return;}refreshScreenshotsAsync(false);}

    private void requestRename(long id,String requested){
        String clean=requested==null?"":requested.trim().replace("/","").replace("\\","");if(clean.isEmpty()){webView.evaluateJavascript("window.onRenameResult(false)",null);return;}pendingRenameId=id;pendingRenameName=clean;
        Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));
        try{if(Build.VERSION.SDK_INT>=30){ArrayList<Uri> one=new ArrayList<>();one.add(uri);PendingIntent request=MediaStore.createWriteRequest(getContentResolver(),one);startIntentSenderForResult(request.getIntentSender(),WRITE_REQUEST,null,0,0,0);}else performRename();}catch(Exception e){webView.evaluateJavascript("window.onRenameResult(false)",null);}
    }
    private void performRename(){
        try{Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(pendingRenameId));String oldName="";try(Cursor c=getContentResolver().query(uri,new String[]{MediaStore.Images.Media.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())oldName=c.getString(0);}String finalName=pendingRenameName;if(!finalName.contains(".")&&oldName!=null&&oldName.lastIndexOf('.')>0)finalName+=oldName.substring(oldName.lastIndexOf('.'));ContentValues values=new ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,finalName);int changed=getContentResolver().update(uri,values,null,null);webView.evaluateJavascript("window.onRenameResult("+(changed>0)+")",null);if(changed>0)refreshScreenshotsAsync(false);}catch(Exception e){webView.evaluateJavascript("window.onRenameResult(false)",null);}
    }

    private void prepareReminder(String title,long time,int id){
        pendingReminderTitle=title;pendingReminderTime=time;pendingReminderId=id;
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);return;}
        scheduleReminderNow(title,time,id);
    }
    private void scheduleReminderNow(String title,long time,int id){
        try{Intent intent=new Intent(this,ReminderReceiver.class).putExtra("title",title).putExtra("id",id);PendingIntent pending=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,time,pending);webView.evaluateJavascript("window.onReminderScheduled(true)",null);}catch(Exception e){webView.evaluateJavascript("window.onReminderScheduled(false)",null);}
    }
    private void cancelReminderNow(int id){Intent intent=new Intent(this,ReminderReceiver.class);PendingIntent pending=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pending!=null){AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);alarm.cancel(pending);pending.cancel();}}

    @Override public void onBackPressed(){webView.evaluateJavascript("window.appBack()",null);}
    @Override protected void onDestroy(){mainHandler.removeCallbacksAndMessages(null);try{getContentResolver().unregisterContentObserver(mediaObserver);}catch(Exception ignored){}if(latinRecognizer!=null)latinRecognizer.close();if(koreanRecognizer!=null)koreanRecognizer.close();if(japaneseRecognizer!=null)japaneseRecognizer.close();if(chineseRecognizer!=null)chineseRecognizer.close();if(webView!=null)webView.destroy();super.onDestroy();}
}
