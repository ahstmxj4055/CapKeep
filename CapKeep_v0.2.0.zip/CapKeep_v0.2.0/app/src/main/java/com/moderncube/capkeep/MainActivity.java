package com.moderncube.capkeep;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PHOTO_PERMISSION = 41;
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GalleryBridge(), "CapKeepAndroid");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private String permissionName() { return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE; }
    private boolean hasPhotoPermission() {
        if (Build.VERSION.SDK_INT < 23) return true;
        if (checkSelfPermission(permissionName()) == PackageManager.PERMISSION_GRANTED) return true;
        return Build.VERSION.SDK_INT >= 34 && checkSelfPermission(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) == PackageManager.PERMISSION_GRANTED;
    }
    private void askPhotoPermission() {
        if (Build.VERSION.SDK_INT >= 34) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED}, PHOTO_PERMISSION);
        else if (Build.VERSION.SDK_INT >= 23) requestPermissions(new String[]{permissionName()}, PHOTO_PERMISSION);
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == PHOTO_PERMISSION) webView.evaluateJavascript("window.onPhotoPermission(" + hasPhotoPermission() + ")", null);
    }

    private class GalleryBridge {
        @JavascriptInterface public boolean hasPermission() { return hasPhotoPermission(); }
        @JavascriptInterface public void requestPermission() { runOnUiThread(() -> askPhotoPermission()); }
        @JavascriptInterface public String getScreenshots() {
            JSONArray out = new JSONArray();
            if (!hasPhotoPermission()) return out.toString();
            String[] cols = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED};
            String order = MediaStore.Images.Media.DATE_ADDED + " DESC LIMIT 200";
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cols, null, null, order)) {
                if (c == null) return out.toString();
                int idCol=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID), nameCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME), dateCol=c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
                while (c.moveToNext() && out.length() < 120) {
                    long id=c.getLong(idCol); String name=c.getString(nameCol); if(name==null) name="";
                    String lower=name.toLowerCase();
                    if (!(lower.contains("screenshot") || lower.contains("스크린샷") || lower.contains("capture"))) continue;
                    Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                    JSONObject item=new JSONObject(); item.put("id",id); item.put("name",name); item.put("date",c.getLong(dateCol)); item.put("thumb",thumbnail(uri)); out.put(item);
                }
            } catch (Exception ignored) {}
            return out.toString();
        }
        private String thumbnail(Uri uri) {
            try (InputStream in=getContentResolver().openInputStream(uri)) {
                Bitmap src=BitmapFactory.decodeStream(in); if(src==null) return "";
                int max=360,w=src.getWidth(),h=src.getHeight(); float scale=Math.min(1f,(float)max/Math.max(w,h));
                Bitmap small=scale<1f?Bitmap.createScaledBitmap(src,Math.max(1,(int)(w*scale)),Math.max(1,(int)(h*scale)),true):src;
                ByteArrayOutputStream bytes=new ByteArrayOutputStream(); small.compress(Bitmap.CompressFormat.JPEG,68,bytes);
                if(small!=src) small.recycle(); src.recycle();
                return "data:image/jpeg;base64,"+Base64.encodeToString(bytes.toByteArray(),Base64.NO_WRAP);
            } catch(Exception e) { return ""; }
        }
    }

    @Override public void onBackPressed() { webView.evaluateJavascript("document.querySelector('.screen.on').id", value -> { if("\"home\"".equals(value)) finish(); else webView.evaluateJavascript("window.appBack()",null); }); }
    @Override protected void onDestroy() { if(webView!=null) webView.destroy(); super.onDestroy(); }
}
